#!/bin/sh
java -jar TimeMasterApp.jar
